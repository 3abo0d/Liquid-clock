# ClockGlass 1.1.0 — Glyph Glass

This build does not use rounded-rectangle glass cards. It draws each original ColorOS big-clock digit as a glyph path, clips the glass shader to that exact path, and samples the lock-screen wallpaper bitmap underneath the glyph.

## Target

- ColorOS big lock-screen clock nodes identified by the ClockProbe: `visible_digital_time_view` inside `BigClockDigitalTimeView`.
- SystemUI only (`com.android.systemui`).
- Android 14+ required for the lock-wallpaper API and `RuntimeShader`; the target device is Android 16.

## Safety behavior

The original digit is hidden only after a replacement view has been created and added successfully. If the wallpaper cannot be read, the shader fails, or attachment fails, the stock digit is left visible/restored. Disabling the LSPosed module and restarting SystemUI also restores the stock clock.

The wallpaper is read through `WallpaperManager` in the SystemUI process (which has the platform wallpaper permission on supported builds). Lock wallpaper is preferred; system wallpaper is a fallback. If both are unavailable (for example, a live lock-screen wallpaper), the module deliberately skips replacement rather than showing a fake opaque panel.

## Build

GitHub Actions builds `app/build/outputs/apk/debug/app-debug.apk` on push or manual dispatch. The module uses no third-party glass library; the glyph mask and AGSL shader are implemented in this project.

## Enable

Install the APK, enable **Clock Glass** in LSPosed with **System UI** in scope, then restart SystemUI. Logs use the `ClockGlass:` tag.

## Remove

Disable the LSPosed module, restart SystemUI, then uninstall `com.clockglass` if desired.
