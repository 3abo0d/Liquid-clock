# ClockGlass 1.1 implementation handoff

## Design

A per-digit `GlyphGlassView` is placed in the parent `ViewGroupOverlay`, not inserted as a normal child, so it cannot alter the OEM clock's measure/layout pass. Visibility and text changes are hooked so digits that become visible after initial attachment are also replaced. A per-digit `GlyphGlassView` renders the actual glyph outline obtained from the original `TextView`'s `TextPaint`, text, layout line-left, and baseline. A small alpha mask bitmap is generated from that glyph path. An Android `RuntimeShader` samples the lock wallpaper bitmap and uses the mask's alpha gradient to create a small edge-normal displacement, restrained five-tap wallpaper diffusion, a cool translucent tint, and a subtle reflective rim. The canvas is clipped to the glyph path, so there are no rectangular glass cells.

## Verified assumptions from device diagnostics

- The lock clock is the ColorOS personality big clock.
- Visible digit nodes are `TextView` instances named `visible_digital_time_view`.
- Their ancestor class is `BigClockDigitalTimeView`.
- SystemUI is the target process.

## Runtime conditions that still require device verification

- Whether this specific ColorOS build grants SystemUI access to `WallpaperManager.getDrawable(FLAG_LOCK)`.
- Whether OPPO's lock wallpaper is static and exposed as a Drawable. If it is a live wallpaper or returns null, replacement is skipped and stock digits remain.
- Whether the OEM's actual wallpaper crop exactly matches the center-crop used for the shader bitmap. The shader maps the returned drawable to the display dimensions; vendor parallax/dimming can differ.
- Actual AGSL performance and appearance on the CPH2781.

This is a reasoned implementation, not a claim of device-tested success. Build success is not runtime verification.
