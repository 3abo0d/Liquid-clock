# Third-party notices

The app uses the Android platform APIs and the Xposed API surface at runtime. The `stubs` module contains compile-only API declarations and is not packaged into the APK. No third-party glass-rendering library is included; the glyph mask and AGSL material renderer are implemented in this project.
