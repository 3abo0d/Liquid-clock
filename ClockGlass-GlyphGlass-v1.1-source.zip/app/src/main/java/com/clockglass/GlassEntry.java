package com.clockglass;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.text.TextPaint;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.TextView;

import java.lang.reflect.Constructor;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * ClockGlass v1.0 - glyph-masked wallpaper glass.
 *
 * Replaces only the four confirmed ColorOS BigClockDigitalTimeView text nodes.
 * Each replacement draws the real glyph outline as a Path, clips the material
 * to that path, and shades the wallpaper bitmap through the glyph mask. If the
 * lock wallpaper cannot be read or shader setup fails, the stock digit remains.
 */
public final class GlassEntry implements IXposedHookLoadPackage {
    private static final String TAG = "ClockGlass";
    private static final String DIGIT_ID = "visible_digital_time_view";
    private static final String DIGIT_PARENT = "BigClockDigitalTimeView";
    private static final Map<TextView, GlyphGlassView> ACTIVE = new WeakHashMap<>();
    private static volatile Bitmap wallpaperBitmap;
    private static volatile String wallpaperFailure;

    private static final String AGSL =
            "uniform shader wallpaper;\\n" +
            "uniform shader glyphMask;\\n" +
            "uniform float2 origin;\\n" +
            "uniform float refraction;\\n" +
            "uniform float blurRadius;\\n" +
            "half4 main(float2 p) {\\n" +
            "  float2 texel = float2(1.5, 1.5);\\n" +
            "  float leftA = glyphMask.eval(p - float2(texel.x, 0.0)).a;\\n" +
            "  float rightA = glyphMask.eval(p + float2(texel.x, 0.0)).a;\\n" +
            "  float topA = glyphMask.eval(p - float2(0.0, texel.y)).a;\\n" +
            "  float bottomA = glyphMask.eval(p + float2(0.0, texel.y)).a;\\n" +
            "  float2 grad = float2(rightA - leftA, bottomA - topA);\\n" +
            "  float edge = clamp(length(grad) * 1.8, 0.0, 1.0);\\n" +
            "  float2 normal = normalize(grad + float2(0.00001, 0.00001));\\n" +
            "  float2 samplePoint = p + origin - normal * (refraction * edge);\\n" +
            "  float2 b = float2(blurRadius, blurRadius);\\n" +
            "  half4 c = wallpaper.eval(samplePoint) * 0.52;\\n" +
            "  c += wallpaper.eval(samplePoint + float2(b.x, 0.0)) * 0.12;\\n" +
            "  c += wallpaper.eval(samplePoint - float2(b.x, 0.0)) * 0.12;\\n" +
            "  c += wallpaper.eval(samplePoint + float2(0.0, b.y)) * 0.12;\\n" +
            "  c += wallpaper.eval(samplePoint - float2(0.0, b.y)) * 0.12;\\n" +
            "  float rim = smoothstep(0.02, 0.75, edge);\\n" +
            "  float sheen = 0.035 + rim * 0.12;\\n" +
            "  c.rgb = mix(c.rgb, half3(0.88, 0.94, 1.0), 0.055);\\n" +
            "  c.rgb = mix(c.rgb, half3(1.0), sheen);\\n" +
            "  c.a = 1.0;\\n" +
            "  return c;\\n" +
            "}";

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        log("v1.0 loaded in " + lp.processName);
        try {
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    View v = (View) p.thisObject;
                    if (!(v instanceof TextView) || !DIGIT_ID.equals(idName(v)) || !hasDigitAncestor(v)) return;
                    v.post(() -> attachDigit((TextView) v));
                }
            });
            XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            invalidateReplacement((TextView) p.thisObject);
                        }
                    });
            XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class,
                    TextView.BufferType.class, new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            invalidateReplacement((TextView) p.thisObject);
                        }
                    });
            XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    View v = (View) p.thisObject;
                    if (!(v instanceof TextView) || !DIGIT_ID.equals(idName(v)) || !hasDigitAncestor(v)) return;
                    if (v.getVisibility() == View.VISIBLE) v.post(() -> attachDigit((TextView) v));
                    else restoreDigit((TextView) v);
                }
            });
            XposedHelpers.findAndHookMethod(View.class, "onDetachedFromWindow", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    View v = (View) p.thisObject;
                    if (v instanceof TextView && DIGIT_ID.equals(idName(v))) restoreDigit((TextView) v);
                }
            });
            log("hooks installed");
        } catch (Throwable t) {
            log("hook installation failed; stock clock untouched: " + t);
        }
    }

    private static boolean hasDigitAncestor(View v) {
        ViewParent p = v.getParent();
        for (int i = 0; i < 6 && p instanceof View; i++) {
            View a = (View) p;
            if (a.getClass().getName().contains(DIGIT_PARENT)) return true;
            p = a.getParent();
        }
        return false;
    }

    private static void attachDigit(TextView original) {
        if (!original.isAttachedToWindow() || original.getParent() == null
                || original.getVisibility() != View.VISIBLE
                || original.getText() == null || original.getText().length() == 0) return;
        ViewGroup parent = original.getParent() instanceof ViewGroup ? (ViewGroup) original.getParent() : null;
        if (parent == null) return;
        synchronized (ACTIVE) { if (ACTIVE.containsKey(original)) return; }

        Bitmap wallpaper = getLockWallpaper(original.getContext());
        if (wallpaper == null) {
            log("replacement skipped; wallpaper unavailable: " + wallpaperFailure);
            return;
        }

        GlyphGlassView replacement = null;
        float oldAlpha = original.getAlpha();
        try {
            replacement = new GlyphGlassView(original.getContext(), original, wallpaper, parent);
            replacement.layout(original.getLeft(), original.getTop(),
                    original.getRight(), original.getBottom());
            // ViewGroupOverlay does not participate in the parent's measure/layout pass.
            // This prevents adding four glass views from shifting or clipping the four clock digits.
            parent.getOverlay().add(replacement);
            synchronized (ACTIVE) { ACTIVE.put(original, replacement); }
            replacement.setSavedAlpha(oldAlpha);
            original.setAlpha(0f);
            replacement.invalidate();
            log("glyph overlay attached: text=" + original.getText() + " bounds="
                    + original.getLeft() + "," + original.getTop() + "-"
                    + original.getRight() + "," + original.getBottom());
        } catch (Throwable t) {
            if (replacement != null) replacement.removeFromOverlay();
            original.setAlpha(oldAlpha);
            synchronized (ACTIVE) { ACTIVE.remove(original); }
            log("replacement failed; stock digit restored: " + t);
        }
    }

    private static Bitmap getLockWallpaper(Context context) {
        Bitmap cached = wallpaperBitmap;
        if (cached != null && !cached.isRecycled()) return cached;
        synchronized (GlassEntry.class) {
            if (wallpaperBitmap != null && !wallpaperBitmap.isRecycled()) return wallpaperBitmap;
            try {
                WallpaperManager wm = WallpaperManager.getInstance(context);
                Drawable drawable = null;
                try { drawable = wm.getDrawable(WallpaperManager.FLAG_LOCK); }
                catch (Throwable lockError) { log("lock wallpaper read failed: " + lockError); }
                if (drawable == null) {
                    try { drawable = wm.getDrawable(WallpaperManager.FLAG_SYSTEM); }
                    catch (Throwable systemError) { log("system wallpaper read failed: " + systemError); }
                }
                if (drawable == null) {
                    wallpaperFailure = "WallpaperManager returned null (live wallpaper or unavailable permission)";
                    return null;
                }

                Point size = displaySize(context);
                if (size.x <= 0 || size.y <= 0) {
                    wallpaperFailure = "could not determine display size";
                    return null;
                }
                Bitmap out = Bitmap.createBitmap(size.x, size.y, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(out);
                int iw = Math.max(1, drawable.getIntrinsicWidth());
                int ih = Math.max(1, drawable.getIntrinsicHeight());
                float scale = Math.max(size.x / (float) iw, size.y / (float) ih);
                int dw = Math.round(iw * scale);
                int dh = Math.round(ih * scale);
                int left = (size.x - dw) / 2;
                int top = (size.y - dh) / 2;
                drawable.setBounds(left, top, left + dw, top + dh);
                drawable.draw(canvas);
                wallpaperBitmap = out;
                wallpaperFailure = null;
                log("lock wallpaper cached " + size.x + "x" + size.y + " source=" + iw + "x" + ih);
                return out;
            } catch (Throwable t) {
                wallpaperFailure = t.toString();
                log("wallpaper capture failed: " + t);
                return null;
            }
        }
    }

    private static Point displaySize(Context context) {
        Point p = new Point();
        try {
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            Display display = wm.getDefaultDisplay();
            display.getRealSize(p);
        } catch (Throwable ignored) {
            p.x = context.getResources().getDisplayMetrics().widthPixels;
            p.y = context.getResources().getDisplayMetrics().heightPixels;
        }
        return p;
    }

    private static void invalidateReplacement(TextView original) {
        GlyphGlassView view;
        synchronized (ACTIVE) { view = ACTIVE.get(original); }
        if (view != null) view.invalidateGlyph();
        else if (DIGIT_ID.equals(idName(original)) && hasDigitAncestor(original)
                && original.isAttachedToWindow() && original.getVisibility() == View.VISIBLE) {
            original.post(() -> attachDigit(original));
        }
    }

    private static void restoreDigit(TextView original) {
        try {
            GlyphGlassView view;
            synchronized (ACTIVE) { view = ACTIVE.remove(original); }
            if (view == null) return;
            original.setAlpha(view.savedAlpha());
            view.removeFromOverlay();
        } catch (Throwable t) { log("restore failed: " + t); }
    }

    private static final class GlyphGlassView extends View {
        private final TextView source;
        private final Bitmap wallpaper;
        private final ViewGroup overlayHost;
        private final View.OnLayoutChangeListener sourceLayoutListener;
        private final Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path glyph = new Path();
        private Bitmap maskBitmap;
        private BitmapShader maskShader;
        private RuntimeShader runtimeShader;
        private float savedAlpha = 1f;
        private String lastText = "";
        private int lastWidth = -1;
        private int lastHeight = -1;

        GlyphGlassView(Context context, TextView source, Bitmap wallpaper, ViewGroup overlayHost) {
            super(context);
            this.source = source;
            this.wallpaper = wallpaper;
            this.overlayHost = overlayHost;
            this.sourceLayoutListener = (v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
                layout(left, top, right, bottom);
                invalidateGlyph();
            };
            source.addOnLayoutChangeListener(sourceLayoutListener);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            BitmapShader wallpaperShader = new BitmapShader(wallpaper, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            runtimeShader = new RuntimeShader(AGSL);
            runtimeShader.setInputShader("wallpaper", wallpaperShader);
            glassPaint.setShader(runtimeShader);
            glassPaint.setStyle(Paint.Style.FILL);
            edgePaint.setStyle(Paint.Style.STROKE);
            edgePaint.setStrokeJoin(Paint.Join.ROUND);
            edgePaint.setStrokeCap(Paint.Cap.ROUND);
            edgePaint.setStrokeWidth(dp(context, 0.85f));
            edgePaint.setColor(0x55FFFFFF);
            maskPaint.setColor(Color.WHITE);
            rebuildGlyph();
        }

        void setSavedAlpha(float alpha) { savedAlpha = alpha; }
        float savedAlpha() { return savedAlpha; }
        void removeFromOverlay() {
            source.removeOnLayoutChangeListener(sourceLayoutListener);
            try { overlayHost.getOverlay().remove(this); } catch (Throwable ignored) { }
        }
        void invalidateGlyph() { rebuildGlyph(); invalidate(); }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            rebuildGlyph();
        }

        private void rebuildGlyph() {
            if (getWidth() <= 0 || getHeight() <= 0) return;
            CharSequence chars = source.getText();
            String text = chars == null ? "" : chars.toString();
            if (text.isEmpty()) return;
            if (maskBitmap != null && !maskBitmap.isRecycled()) maskBitmap.recycle();
            maskBitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ALPHA_8);
            Canvas maskCanvas = new Canvas(maskBitmap);
            glyph.reset();
            TextPaint textPaint = new TextPaint(source.getPaint());
            Layout layout = source.getLayout();
            float x = layout != null ? source.getCompoundPaddingLeft() + layout.getLineLeft(0)
                    : (getWidth() - textPaint.measureText(text)) * 0.5f;
            float baseline = source.getBaseline();
            textPaint.setStyle(Paint.Style.FILL);
            textPaint.setColor(Color.WHITE);
            textPaint.getTextPath(text, 0, text.length(), x, baseline, glyph);
            maskCanvas.drawPath(glyph, maskPaint);
            maskShader = new BitmapShader(maskBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            runtimeShader.setInputShader("glyphMask", maskShader);
            lastText = text;
            lastWidth = getWidth();
            lastHeight = getHeight();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (getWidth() <= 0 || getHeight() <= 0) return;
            String now = source.getText() == null ? "" : source.getText().toString();
            if (!now.equals(lastText) || getWidth() != lastWidth || getHeight() != lastHeight) rebuildGlyph();
            if (glyph.isEmpty() || runtimeShader == null) return;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            runtimeShader.setFloatUniform("origin", (float) loc[0], (float) loc[1]);
            runtimeShader.setFloatUniform("refraction", dp(getContext(), 2.0f));
            // A restrained five-tap sample gives the wallpaper a soft glass diffusion,
            // not the heavy frosted blur that would hide the lock-screen artwork.
            runtimeShader.setFloatUniform("blurRadius", dp(getContext(), 1.0f));
            canvas.save();
            canvas.clipPath(glyph);
            canvas.drawRect(0, 0, getWidth(), getHeight(), glassPaint);
            canvas.restore();
            edgePaint.setColor(0x55FFFFFF);
            canvas.drawPath(glyph, edgePaint);
            edgePaint.setStrokeWidth(dp(getContext(), 0.4f));
            edgePaint.setColor(0x22FFFFFF);
            canvas.drawPath(glyph, edgePaint);
        }
    }

    private static ViewGroup.LayoutParams copyLayoutParams(ViewGroup.LayoutParams source) throws Exception {
        if (source == null) return new ViewGroup.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        for (Constructor<?> ctor : source.getClass().getConstructors()) {
            Class<?>[] types = ctor.getParameterTypes();
            if (types.length == 1 && types[0].isAssignableFrom(source.getClass()))
                return (ViewGroup.LayoutParams) ctor.newInstance(source);
        }
        if (source instanceof ViewGroup.MarginLayoutParams)
            return new ViewGroup.MarginLayoutParams((ViewGroup.MarginLayoutParams) source);
        return new ViewGroup.LayoutParams(source);
    }

    private static final int WRAP_CONTENT = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static float dp(Context c, float value) { return value * c.getResources().getDisplayMetrics().density; }

    private static String idName(View v) {
        if (v.getId() == View.NO_ID) return "-";
        try { return v.getResources().getResourceEntryName(v.getId()); }
        catch (Throwable t) { return "0x" + Integer.toHexString(v.getId()); }
    }

    private static void log(String message) {
        Log.i(TAG, message);
        try { XposedBridge.log(TAG + ": " + message); } catch (Throwable ignored) { }
    }
}
