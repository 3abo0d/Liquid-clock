# HANDOFF: Liquid Glass lock screen on Oppo A6 Pro 5G (ColorOS 16)

Paste this whole file into a new chat to continue.

## Goal
Liquid Glass (iOS 26 style) lock screen on a rooted Oppo A6 Pro 5G. Current step: a glass lens behind the big lock screen clock digits. Later: glass media card, native lyrics page, capsule, AOD features. Must be reversible, must never break the stock lock screen.

## Device and tooling
- Phone: Oppo A6 Pro 5G (CPH2781, global EX01), ColorOS 16.0.5.1300, Android 16, SystemUI 16.00.14
- Root: KernelSU-Next, LSPosed 2.2.1, Zygisk Next 1.5.3, OverlayFS MetaModule. Earlier "dirtyfrag" root is temporary.
- Works only from the phone: aShell (root), MT Manager, GitHub in browser, GitHub Actions for builds. No PC.
- Earlier flag change (fluid_flags_unlock) caused zygote crashes. Test one change at a time and keep a recovery path.

## User preferences
- Complete source ZIPs and full workflow files, copyable text, no guessed signatures
- Do not claim a feature works before it is tested on the phone
- Run aShell commands one at a time (multi-line pastes break)
- Keep the Control Center repos (Project-zero, Native-FluidGlass-LSPosed) untouched. New work goes in new repos.

## Verified facts (from the probe log on the phone)
- The visible lock screen clock is OPPO's personality "big clock", NOT kgd_single_clock (that layout never inflates).
- Settings: keyguard_style_clock_enabled=1, personality pkg com.oplus.keyguard.clock.big, font OPPOBigClock01.ttf, lock_screen_custom_clock_face=SingleClockProvider (not the visible one).
- View tree: keyguard_style_clock (CustomOplusKeyguardStyleClock, in SystemUI)
  > ClockViewRoot > MyCustomizedFrameLayout#clock_time_parent > ClockTimeView#clock_time
  > BigClockDigitalTimeContainer (clock_time_hour_container, clock_time_minutes_container)
  > 4x BigClockDigitalTimeView (hour_first/second_txt, minutes_first/second_txt)
  > each has MyCustomizedTextView visible_digital_time_view + inVisible_digital_time_view
- Date: date_message_view_parent > DateMessageView > date_text, week_text. Also widgets_container (StyleWidgetsContainer).
- Clock classes live in plugin APKs: /system_ext/app/KeyguardPersonalityClocks/KeyguardPersonalityClocks.apk (com.oplus.keyguard.personality.clocks) and KeyguardClockBase. Their views are created with the plugin context, so hook by view class name and id, not by class loading.
- SystemUI.apk (/system_ext/priv-app/SystemUI/SystemUI.apk, 9 dex files) contains SingleClockView, DualClockView, ClockEventController.
- Other lock screen views seen: media_carousel (OplusMediaCarouselView in MediaScrollView), oplus_qs_media_panel (OplusQsNormalMediaPanelView), keyguard_media_container, keyguard_notification_capsule_view (KeyguardNotificationCapsuleView, native capsule EXISTS), seedling_capsule_container (SystemUIPlugin.apk), kgd_pictoral_preload_view_layout (PictorialPreloadView, wallpaper related), keyguard_style_clock, AOD: AodRootLayout, AodClockLayout.
- The Google AI chat was wrong on several points: kgd_single_clock is not the visible clock; the stub-class build trick risks shadowing real Xposed classes; the manifest xmlns it gave was wrong.

## Projects and status
1. ClockProbe (com.clockprobe): log-only LSPosed probe. DONE, works. Logs go to the LSPosed log:
   grep -h "ClockProbe:" /data/adb/lspd/log/verbose_*.log | sed 's/.*ClockProbe: //; s/ loader=dalvik.*//' > /sdcard/Download/clockprobe.txt
   (The app files-dir log file never got written; ignore it.)
2. ClockGlass v0.1 (com.clockglass): NEW, UNTESTED, not yet built. Adds a com.example.liquidglass.LiquidGlassView behind clock_time via reflection (setters by name). Needs a GitHub Actions build first.
3. Native-FluidGlass-LSPosed (com.liquidglass.nativecc) and the V2 Control Center module: existing, do not modify.

## Build method (works from the phone)
New GitHub repo containing ONLY: ClockGlass-src.zip (uploaded as a zip, not unzipped) and .github/workflows/build.yml (the workflow unzips and builds with Gradle 8.11.1, AGP 8.9.1, compileSdk 36, JDK 17). Download the artifact ClockGlass-APK, install, enable in LSPosed (scope: System UI), then run: killall com.android.systemui
Xposed API is compile-only stubs in a separate :stubs module (not packaged).

## Known risks for ClockGlass v0.1
- Wallpaper may be drawn by a separate window, so a view-based backdrop capture could be blank. If the lens looks empty, find what draws the lock wallpaper (PictorialPreloadView / KeyguardSliderLayout, or the wallpaper service window) and point setBackdropSource at it.
- The glass library's native code and resources must load inside the SystemUI process from the module APK. The log shows exact failures (look for ClockGlass: lines).
- Library method names are called by reflection. "no usable method" log lines name any that are wrong. Library docs: github.com/QWEA0/Liquid-Glass-Android (README, llms.txt, docs/LIQUID_GLASS_V2.md).
- Recovery if SystemUI crash-loops: adb or aShell root: pm uninstall com.clockglass  (then killall com.android.systemui)

## Next steps
1. Build ClockGlass, install, enable, restart SystemUI, lock/unlock, read the ClockGlass log lines (same grep, with ClockGlass: instead of ClockProbe:).
2. Based on the log: fix reflection names, fix the backdrop source, size the lens to the digit block instead of the whole clock_time_parent.
3. Then: glass media card (OplusMediaCarouselView / OplusQsNormalMediaPanelView), native lyrics page, capsule styling, AOD features.
