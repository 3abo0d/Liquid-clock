package com.clockglass;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * ClockGlass v0.1
 *
 * Puts a LiquidGlassView lens BEHIND the digits of the ColorOS 16 big lock screen clock.
 * The stock clock is never modified or replaced. The lens is one extra child view that
 * can be removed by disabling this module and restarting SystemUI.
 *
 * Target (from the probe log):
 *   keyguard_style_clock > ClockViewRoot > clock_time_parent > clock_time (ClockTimeView)
 *
 * The glass library is used through reflection on purpose: if a method name is wrong,
 * the log says exactly which one, and the lock screen is never affected.
 */
public class GlassEntry implements IXposedHookLoadPackage {

    private static final String TAG = "ClockGlass";
    private static final String GLASS_CLASS = "com.example.liquidglass.LiquidGlassView";
    private static final String GLASS_TAG = "clockglass_lens";
    private static final String CLOCK_CLASS_SUFFIX = ".ClockTimeView";
    private static final String CLOCK_ID_NAME = "clock_time";

    // Visible tint so you can confirm the lens is attached even if refraction is subtle.
    private static final int TINT_ARGB = 0x30FFFFFF;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!"com.android.systemui".equals(lpparam.packageName)) {
            return;
        }
        log("loaded in " + lpparam.processName);
        try {
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                final View v = (View) param.thisObject;
                                if (!v.getClass().getName().endsWith(CLOCK_CLASS_SUFFIX)) {
                                    return;
                                }
                                if (!CLOCK_ID_NAME.equals(idName(v))) {
                                    return;
                                }
                                // Never add a child while the parent is dispatching attach.
                                v.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        attachGlass(v);
                                    }
                                });
                            } catch (Throwable t) {
                                log("attach hook error: " + t);
                            }
                        }
                    });
            log("hook installed");
        } catch (Throwable t) {
            log("could not hook View.onAttachedToWindow: " + t);
        }
    }

    private static void attachGlass(View clock) {
        try {
            ViewParent pp = clock.getParent();
            if (!(pp instanceof FrameLayout)) {
                log("clock parent is not a FrameLayout: " + (pp == null ? "null" : pp.getClass().getName()));
                return;
            }
            FrameLayout parent = (FrameLayout) pp;
            if (parent.findViewWithTag(GLASS_TAG) != null) {
                return; // already attached
            }

            Object obj = createGlass(clock.getContext());
            if (!(obj instanceof View)) {
                log("glass object is not a View: " + obj);
                return;
            }
            final View glass = (View) obj;
            glass.setTag(GLASS_TAG);
            configure(glass, clock);

            int index = Math.max(parent.indexOfChild(clock), 0); // behind the digits
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            parent.addView(glass, index, lp);

            log("lens attached behind " + clock.getClass().getName()
                    + " in " + parent.getClass().getName() + " at index " + index);

            glass.postDelayed(new Runnable() {
                @Override
                public void run() {
                    log("lens size " + glass.getWidth() + "x" + glass.getHeight()
                            + " vis=" + glass.getVisibility() + " attached=" + glass.isAttachedToWindow());
                }
            }, 1500);
        } catch (Throwable t) {
            log("attach failed: " + t + " | " + shortStack(t));
        }
    }

    private static Object createGlass(Context ctx) throws Exception {
        Class<?> c = Class.forName(GLASS_CLASS, true, GlassEntry.class.getClassLoader());
        try {
            return c.getConstructor(Context.class).newInstance(ctx);
        } catch (NoSuchMethodException e) {
            return c.getConstructor(Context.class, AttributeSet.class).newInstance(ctx, null);
        }
    }

    private static void configure(View glass, View clock) {
        float d = clock.getContext().getResources().getDisplayMetrics().density;

        call(glass, "setCornerRadius", 44f * d);
        call(glass, "setRefractionHeight", 22f * d);
        call(glass, "setBevelWidth", 30f * d);
        call(glass, "setDispersionStrength", 0.12f);
        call(glass, "setGlassTint", TINT_ARGB);
        call(glass, "setEnableDynamicBackground", true);
        call(glass, "setEnablePressEffect", false);
        call(glass, "setEnableSensorHighlight", false);

        // Backdrop: the top of this window's view tree.
        View root = clock;
        while (root.getParent() instanceof View) {
            root = (View) root.getParent();
        }
        call(glass, "setBackdropSource", root);
        log("backdrop source = " + root.getClass().getName() + "#" + idName(root));

        // The lens must never eat touches meant for the lock screen.
        glass.setClickable(false);
        glass.setFocusable(false);
        glass.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    /** Calls a setter by name and argument count; logs instead of throwing. */
    private static boolean call(Object target, String name, Object... args) {
        Method[] methods = target.getClass().getMethods();
        for (Method m : methods) {
            if (!m.getName().equals(name) || m.getParameterTypes().length != args.length) {
                continue;
            }
            try {
                m.invoke(target, args);
                return true;
            } catch (IllegalArgumentException e) {
                // wrong overload, try the next one
            } catch (Throwable t) {
                log(name + " failed: " + t);
                return false;
            }
        }
        log("no usable method: " + name + "/" + args.length);
        return false;
    }

    private static String idName(View v) {
        int id = v.getId();
        if (id == View.NO_ID) {
            return "-";
        }
        try {
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "0x" + Integer.toHexString(id);
        }
    }

    private static String shortStack(Throwable t) {
        Throwable root = t;
        while (root.getCause() != null && root.getCause() != root) {
            root = root.getCause();
        }
        StringBuilder sb = new StringBuilder(root.toString());
        StackTraceElement[] st = root.getStackTrace();
        for (int i = 0; i < st.length && i < 6; i++) {
            sb.append(" <- ").append(st[i].getClassName()).append('.').append(st[i].getMethodName());
        }
        return sb.toString();
    }

    private static void log(String msg) {
        Log.i(TAG, msg);
        try {
            XposedBridge.log(TAG + ": " + msg);
        } catch (Throwable ignored) {
        }
    }
}
