package com.clockglass;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * ClockGlass v0.3-alpha.
 *
 * Uses the real ColorOS BigClockDigitalTimeView/visible_digital_time_view nodes as
 * the clock/time source. Each visible digit gets its own independently-sized
 * LiquidGlassView surface. The stock digit is made transparent only after its
 * replacement has been attached; it is restored when detached or if setup fails.
 *
 * IMPORTANT: the upstream LiquidGlassView API exposes rounded-rectangle shapes,
 * not arbitrary glyph paths. This alpha therefore produces four separate glass
 * digit cells, not yet a glass material clipped to the exact outline of each
 * numeral. Exact glyph clipping requires a custom mask/backdrop renderer.
 */
public final class GlassEntry implements IXposedHookLoadPackage {
    private static final String TAG = "ClockGlass";
    private static final String GLASS_CLASS = "com.example.liquidglass.LiquidGlassView";
    private static final String DIGIT_ID = "visible_digital_time_view";
    private static final String DIGIT_PARENT = "BigClockDigitalTimeView";
    private static final Map<TextView, GlassDigitOverlay> ACTIVE = new WeakHashMap<>();

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        log("v0.3-alpha loaded in " + lp.processName);
        try {
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        View v = (View) p.thisObject;
                        if (!(v instanceof TextView) || !DIGIT_ID.equals(idName(v))) return;
                        if (!hasDigitAncestor(v)) return;
                        v.post(() -> attachDigit((TextView) v));
                    } catch (Throwable t) { log("attach hook: " + t); }
                }
            });
            XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class,
                    new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    syncText((TextView) p.thisObject);
                }
            });
            XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class,
                    TextView.BufferType.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    syncText((TextView) p.thisObject);
                }
            });
            XposedHelpers.findAndHookMethod(View.class, "onDetachedFromWindow", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    View v = (View) p.thisObject;
                    if (v instanceof TextView && DIGIT_ID.equals(idName(v))) restoreDigit((TextView) v);
                }
            });
            log("hooks installed: digit attach, text updates, detach restore");
        } catch (Throwable t) {
            log("hook installation failed; stock clock left untouched: " + stack(t));
        }
    }

    private static boolean hasDigitAncestor(View v) {
        ViewParent p = v.getParent();
        for (int i = 0; i < 5 && p instanceof View; i++) {
            View a = (View) p;
            if (a.getClass().getName().contains(DIGIT_PARENT)) return true;
            p = a.getParent();
        }
        return false;
    }

    private static void attachDigit(TextView original) {
        if (!original.isAttachedToWindow() || original.getParent() == null) return;
        ViewGroup parent = original.getParent() instanceof ViewGroup ? (ViewGroup) original.getParent() : null;
        if (parent == null) { log("digit parent is not a ViewGroup"); return; }
        synchronized (ACTIVE) { if (ACTIVE.containsKey(original)) return; }
        GlassDigitOverlay overlay = null;
        float oldAlpha = original.getAlpha();
        try {
            overlay = new GlassDigitOverlay(original.getContext(), original);
            ViewGroup.LayoutParams oldLp = original.getLayoutParams();
            ViewGroup.LayoutParams lp = oldLp == null
                    ? new ViewGroup.LayoutParams(original.getWidth(), original.getHeight())
                    : copyLayoutParams(oldLp);
            int index = parent.indexOfChild(original);
            parent.addView(overlay, Math.min(index + 1, parent.getChildCount()), lp);
            synchronized (ACTIVE) { ACTIVE.put(original, overlay); }
            overlay.setOriginalAlpha(oldAlpha);
            original.setAlpha(0f);
            overlay.bringToFront();
            log("individual glass digit attached id=" + idName(original)
                    + " size=" + original.getWidth() + "x" + original.getHeight());
        } catch (Throwable t) {
            if (overlay != null && overlay.getParent() instanceof ViewGroup)
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            original.setAlpha(oldAlpha);
            synchronized (ACTIVE) { ACTIVE.remove(original); }
            log("digit replacement failed; stock digit restored: " + stack(t));
        }
    }

    private static void syncText(TextView original) {
        try {
            GlassDigitOverlay overlay;
            synchronized (ACTIVE) { overlay = ACTIVE.get(original); }
            if (overlay != null) overlay.syncFromOriginal();
        } catch (Throwable t) { log("digit sync failed: " + t); }
    }

    private static void restoreDigit(TextView original) {
        try {
            GlassDigitOverlay overlay;
            synchronized (ACTIVE) { overlay = ACTIVE.remove(original); }
            if (overlay == null) return;
            original.setAlpha(overlay.originalAlpha());
            if (overlay.getParent() instanceof ViewGroup)
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            log("stock digit restored on detach");
        } catch (Throwable t) { log("restore failed: " + t); }
    }

    private static final class GlassDigitOverlay extends FrameLayout {
        private final TextView original;
        private final TextView face;
        private final View glass;
        private float savedAlpha = 1f;

        GlassDigitOverlay(Context context, TextView source) throws Exception {
            super(context);
            original = source;
            setClipChildren(false);
            setClipToPadding(false);
            setClickable(false);
            setFocusable(false);
            setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);

            glass = newGlass(context);
            if (!(glass instanceof View)) throw new IllegalStateException("LiquidGlassView is not a View");
            addView(glass, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            configureGlass(glass, source);

            face = new TextView(context);
            copyTextStyle(source, face);
            FrameLayout.LayoutParams textLp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            addView(face, textLp);
            syncFromOriginal();
        }

        void setOriginalAlpha(float value) { savedAlpha = value; }
        float originalAlpha() { return savedAlpha; }

        void syncFromOriginal() {
            face.setText(original.getText());
            face.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, original.getTextSize());
            face.setTypeface(original.getTypeface());
            face.setGravity(original.getGravity());
            face.setIncludeFontPadding(original.getIncludeFontPadding());
            face.setLetterSpacing(original.getLetterSpacing());
            face.setTextScaleX(original.getTextScaleX());
            face.setTextColor(0xF2FFFFFF);
            face.setShadowLayer(dp(getContext(), 1.2f), 0f, dp(getContext(), 0.5f), 0x55FFFFFF);
            face.setMaxLines(original.getMaxLines());
            face.setSingleLine(original.isSingleLine());
            face.setEllipsize(original.getEllipsize());
        }
    }

    private static void copyTextStyle(TextView from, TextView to) {
        to.setGravity(from.getGravity());
        to.setIncludeFontPadding(from.getIncludeFontPadding());
        to.setTypeface(from.getTypeface() == null ? Typeface.DEFAULT : from.getTypeface());
        to.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, from.getTextSize());
        to.setLetterSpacing(from.getLetterSpacing());
        to.setTextScaleX(from.getTextScaleX());
        to.setMaxLines(from.getMaxLines());
        to.setSingleLine(from.isSingleLine());
        to.setEllipsize(from.getEllipsize());
    }

    private static ViewGroup.LayoutParams copyLayoutParams(ViewGroup.LayoutParams source) {
        try {
            for (Constructor<?> ctor : source.getClass().getConstructors()) {
                Class<?>[] types = ctor.getParameterTypes();
                if (types.length == 1 && types[0].isAssignableFrom(source.getClass()))
                    return (ViewGroup.LayoutParams) ctor.newInstance(source);
            }
        } catch (Throwable t) { log("layout params copy fallback: " + t); }
        if (source instanceof ViewGroup.MarginLayoutParams)
            return new ViewGroup.MarginLayoutParams((ViewGroup.MarginLayoutParams) source);
        return new ViewGroup.LayoutParams(source);
    }

    private static Object newGlass(Context context) throws Exception {
        Class<?> c = Class.forName(GLASS_CLASS, true, GlassEntry.class.getClassLoader());
        try { return c.getConstructor(Context.class).newInstance(context); }
        catch (NoSuchMethodException ignored) {
            Constructor<?> ctor = c.getConstructor(Context.class, AttributeSet.class);
            return ctor.newInstance(context, null);
        }
    }

    private static void configureGlass(View glass, View digit) {
        float d = digit.getResources().getDisplayMetrics().density;
        // Exact property names and enum spellings are taken from QWEA0/Liquid-Glass-Android README.
        setEnum(glass, "setMaterial", "com.example.liquidglass.GlassMaterial", "CLEAR");
        call(glass, "setCornerRadius", dp(d, 2.0f));
        call(glass, "setRefractionHeight", dp(d, 3.0f));
        call(glass, "setBevelWidth", dp(d, 4.0f));
        call(glass, "setRefractionFalloff", 2.0f);
        call(glass, "setDispersionStrength", 0.018f);
        call(glass, "setBlurAmount", 0.018f);
        call(glass, "setSaturation", 103.0f);
        call(glass, "setGlassTint", 0x08FFFFFF);
        call(glass, "setEnableAdaptiveTint", false);
        call(glass, "setEnableSensorHighlight", false);
        call(glass, "setEnablePressEffect", false);
        call(glass, "setEnableDynamicBackground", true);
        call(glass, "setEnableBackdropBlur", true);
        call(glass, "setEnableEdgeHighlight", true);
        call(glass, "setEdgeHighlightOpacity", 22.0f);

        View root = digit;
        while (root.getParent() instanceof View) root = (View) root.getParent();
        View wallpaper = findWallpaperCandidate(root);
        call(glass, "setBackdropSource", wallpaper != null ? wallpaper : root);
        log("digit backdrop=" + (wallpaper != null ? "kgd_pictoral_preload_view_layout" : "SystemUI root fallback"));
    }

    private static View findWallpaperCandidate(View root) {
        try {
            int id = root.getResources().getIdentifier(
                    "kgd_pictoral_preload_view_layout", "id", "com.android.systemui");
            if (id != 0) return root.findViewById(id);
        } catch (Throwable ignored) {}
        return null;
    }

    private static void setEnum(Object target, String method, String className, String constant) {
        try {
            Class<?> e = Class.forName(className, true, target.getClass().getClassLoader());
            @SuppressWarnings({"unchecked", "rawtypes"}) Object value = Enum.valueOf((Class) e, constant);
            call(target, method, value);
        } catch (Throwable t) { log(method + " enum setup failed: " + t); }
    }

    private static boolean call(Object target, String name, Object... args) {
        for (Method m : target.getClass().getMethods()) {
            if (!m.getName().equals(name) || m.getParameterTypes().length != args.length) continue;
            try { m.invoke(target, args); return true; }
            catch (IllegalArgumentException ignored) { }
            catch (Throwable t) { log(name + " failed: " + t); return false; }
        }
        log("library API unavailable: " + name + "/" + args.length);
        return false;
    }

    private static String idName(View v) {
        if (v.getId() == View.NO_ID) return "-";
        try { return v.getResources().getResourceEntryName(v.getId()); }
        catch (Throwable t) { return "0x" + Integer.toHexString(v.getId()); }
    }
    private static float dp(Context c, float v) { return dp(c.getResources().getDisplayMetrics().density, v); }
    private static float dp(float density, float v) { return density * v; }
    private static String stack(Throwable t) {
        StringBuilder b = new StringBuilder(String.valueOf(t));
        StackTraceElement[] s = t.getStackTrace();
        for (int i = 0; i < Math.min(5, s.length); i++) b.append(" <- ").append(s[i]);
        return b.toString();
    }
    private static void log(String msg) {
        Log.i(TAG, msg);
        try { XposedBridge.log(TAG + ": " + msg); } catch (Throwable ignored) {}
    }
}
