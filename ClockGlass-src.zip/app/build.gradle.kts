plugins {
    id("com.android.application")
}

android {
    namespace = "com.clockglass"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.clockglass"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-glass"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Compile-only Xposed stubs: NOT packaged. LSPosed provides the real classes at runtime.
    compileOnly(project(":stubs"))

    // Glass library (same one your Control Center module uses). Packaged into this APK.
    implementation("com.github.QWEA0:liquidglass:v2.0.11")
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.9.24")
    implementation("androidx.core:core-ktx:1.12.0")
}
