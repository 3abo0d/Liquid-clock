plugins {
    id("com.android.application")
}

android {
    namespace = "com.clockglass"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.clockglass"
        minSdk = 34
        targetSdk = 35
        versionCode = 4
        versionName = "1.0.0-glyph"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Compile-only Xposed API stubs; LSPosed provides the real API at runtime.
    compileOnly(project(":stubs"))
}
