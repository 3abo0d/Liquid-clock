# Third-party notices

## Liquid-Glass-Android

The project depends on `com.github.QWEA0:liquidglass:v2.0.11` from QWEA0/Liquid-Glass-Android.
Copyright and license terms belong to the upstream authors. The upstream project is distributed under the MIT License; see https://github.com/QWEA0/Liquid-Glass-Android and its LICENSE file. The library is consumed as a Gradle dependency and is not copied into this source archive.

## XMorphClock

XMorphClock was reviewed only as a reference for lock-screen clock replacement architecture. No source code from XMorphClock is copied into ClockGlass. Its README explicitly says manufacturer skins including OPPO ColorOS are unsupported, so it is not used as a runtime dependency.
