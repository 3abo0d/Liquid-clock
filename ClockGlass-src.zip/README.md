ClockGlass v0.1 (see HANDOFF.md for the full picture)

Build: see the workflow file shipped next to this zip (build.yml).
Install: enable "Clock Glass" in LSPosed with System UI in scope, then run: killall com.android.systemui
Logs: grep -h "ClockGlass:" /data/adb/lspd/log/verbose_*.log | sed 's/.*ClockGlass: //' > /sdcard/Download/clockglass.txt
Remove: pm uninstall com.clockglass  then killall com.android.systemui
