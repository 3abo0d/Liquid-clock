# ClockGlass v0.3-alpha

An LSPosed module for the OPPO ColorOS 16 personality big lock-screen clock.

## What this alpha does
- Hooks the verified `visible_digital_time_view` nodes under `BigClockDigitalTimeView`.
- Adds one independent `LiquidGlassView` cell per visible digit and mirrors the original digit text/style.
- Hides the stock digit only after its replacement attaches; restores it on detach or setup failure.
- Uses the upstream QWEA0 Liquid-Glass-Android library and its documented property names.

## Important limitation
The upstream library currently exposes rounded-rectangle glass shapes, not arbitrary glyph masks. This alpha therefore makes four separate glass digit cells; it does **not** yet clip the glass to the exact outline of each numeral. True glass-shaped numerals need a custom glyph-mask/backdrop renderer. Also, live wallpaper sampling is not guaranteed on ColorOS because the wallpaper may be drawn in a separate window. The log reports whether the known pictorial preload view was found or whether the SystemUI root fallback was used.

## Build
Use the repository's existing GitHub Actions workflow. Upload this archive as `ClockGlass-src.zip` at the repository root. Keep the workflow's Gradle 8.11.1 / JDK 17 / Android Gradle Plugin 8.9.1 setup.

## Install and test
1. Build the APK with GitHub Actions and install it over the previous `com.clockglass` package.
2. Enable Clock Glass in LSPosed with **System UI** in scope.
3. Restart SystemUI.
4. Check the lock screen and logs before making any further changes.

Logs:
```sh
grep -h "ClockGlass:" /data/adb/lspd/log/verbose_*.log | sed 's/.*ClockGlass: //' > /sdcard/Download/clockglass-v03.txt
```

Rollback:
```sh
pm uninstall com.clockglass
killall com.android.systemui
```

The module is not verified on-device yet. Keep a recovery path and do not assume the wallpaper backdrop is working until the screenshot/log confirms it.
