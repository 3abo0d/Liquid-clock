plugins {
    id("com.android.application")
}

android {
    namespace = "com.clockprobe"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.clockprobe"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-probe"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Compile-only: LSPosed provides the real Xposed classes at runtime.
    // compileOnly means these stubs are NOT packaged into the APK.
    compileOnly(project(":stubs"))
}
