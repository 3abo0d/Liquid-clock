package com.clockprobe;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.File;
import java.io.FileWriter;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * LOG-ONLY probe. Changes nothing on screen.
 * Reports: which clock related layouts get inflated (and by whom),
 * which clock related views actually attach to the window, and whether
 * the key clock classes are visible to SystemUI's own classloader.
 */
public class ProbeEntry implements IXposedHookLoadPackage {

    private static final String TAG = "ClockProbe";
    private static final int MAX_LINES = 800;

    private static final Set<String> SEEN = ConcurrentHashMap.newKeySet();
    private static final AtomicInteger LINES = new AtomicInteger();
    private static final Object FILE_LOCK = new Object();
    private static File logFile;
    private static boolean fileTried;

    private static final String[] CANDIDATE_CLASSES = {
            "com.oplus.systemui.shared.clocks.SingleClockView",
            "com.oplus.systemui.shared.clocks.DualClockView",
            "com.oplus.systemui.shared.clocks.SingleClockProvider",
            "com.android.keyguard.ClockEventController",
            "com.oplus.systemui.keyguard.view.NumberFontVariationTextView",
            "com.oplus.systemui.keyguard.view.ClockExtraTextView"
    };

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!"com.android.systemui".equals(lpparam.packageName)) {
            return;
        }
        log("probe loaded, process=" + lpparam.processName);

        for (String name : CANDIDATE_CLASSES) {
            try {
                Class<?> c = XposedHelpers.findClassIfExists(name, lpparam.classLoader);
                if (c == null) {
                    log("CLASS " + name + " -> NOT visible to SystemUI classloader");
                } else {
                    log("CLASS " + name + " -> found, loader=" + c.getClassLoader());
                }
            } catch (Throwable t) {
                log("CLASS " + name + " check error: " + t);
            }
        }

        hookInflate();
        hookAttach();
        log("hooks installed");
    }

    private void hookInflate() {
        try {
            XposedHelpers.findAndHookMethod(LayoutInflater.class, "inflate",
                    int.class, ViewGroup.class, boolean.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                int resId = (Integer) param.args[0];
                                LayoutInflater inflater = (LayoutInflater) param.thisObject;
                                Context ctx = inflater.getContext();
                                String name;
                                try {
                                    name = ctx.getResources().getResourceEntryName(resId);
                                } catch (Throwable t) {
                                    return;
                                }
                                if (!interestingLayout(name)) {
                                    return;
                                }
                                if (!SEEN.add("inflate:" + name)) {
                                    return;
                                }
                                Object result = param.getResult();
                                log("INFLATE " + name
                                        + " result=" + (result == null ? "null" : result.getClass().getName())
                                        + " ctx=" + ctx.getClass().getName()
                                        + " pkg=" + ctx.getPackageName()
                                        + " loader=" + ctx.getClassLoader());
                                log("  stack: " + stackSummary());
                                if (result instanceof View) {
                                    dumpTree((View) result, 0, 3);
                                }
                            } catch (Throwable t) {
                                log("inflate hook error: " + t);
                            }
                        }
                    });
        } catch (Throwable t) {
            log("could not hook LayoutInflater.inflate: " + t);
        }
    }

    private void hookAttach() {
        try {
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                View v = (View) param.thisObject;
                                String cn = v.getClass().getName();
                                if (!interestingClass(cn)) {
                                    return;
                                }
                                String idName = idName(v);
                                if (!SEEN.add("attach:" + cn + ":" + idName)) {
                                    return;
                                }
                                log("ATTACH " + cn + " id=" + idName
                                        + " vis=" + v.getVisibility()
                                        + " loader=" + v.getClass().getClassLoader());
                                log("  parents: " + parentChain(v));
                            } catch (Throwable t) {
                                log("attach hook error: " + t);
                            }
                        }
                    });
        } catch (Throwable t) {
            log("could not hook View.onAttachedToWindow: " + t);
        }
    }

    private static boolean interestingLayout(String name) {
        String l = name.toLowerCase(Locale.ROOT);
        return l.startsWith("kgd") || l.contains("clock") || l.contains("lyric")
                || l.contains("capsule") || l.contains("media") || l.contains("keyguard");
    }

    private static boolean interestingClass(String cn) {
        String l = cn.toLowerCase(Locale.ROOT);
        return l.contains("clock") || l.contains("lyric") || l.contains("capsule")
                || l.contains("mediacontrol") || l.contains("mediaplayer") || l.contains("kgd");
    }

    private static String idName(View v) {
        int id = v.getId();
        if (id == View.NO_ID) {
            return "-";
        }
        try {
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "0x" + Integer.toHexString(id);
        }
    }

    private static String parentChain(View v) {
        StringBuilder sb = new StringBuilder();
        Object p = v.getParent();
        int depth = 0;
        while (p != null && depth < 8) {
            sb.append(p.getClass().getName());
            if (p instanceof View) {
                sb.append('#').append(idName((View) p));
                p = ((View) p).getParent();
            } else {
                break;
            }
            sb.append(" < ");
            depth++;
        }
        return sb.toString();
    }

    private static void dumpTree(View v, int depth, int maxDepth) {
        StringBuilder sb = new StringBuilder("  ");
        for (int i = 0; i < depth; i++) {
            sb.append("  ");
        }
        sb.append(v.getClass().getName()).append('#').append(idName(v))
                .append(" vis=").append(v.getVisibility());
        log(sb.toString());
        if (v instanceof ViewGroup && depth < maxDepth) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                dumpTree(g.getChildAt(i), depth + 1, maxDepth);
            }
        }
    }

    private static String stackSummary() {
        StackTraceElement[] st = new Throwable().getStackTrace();
        StringBuilder sb = new StringBuilder();
        int added = 0;
        for (StackTraceElement e : st) {
            String c = e.getClassName();
            if (c.startsWith("de.robv") || c.startsWith("LSPHooker") || c.startsWith("com.clockprobe")
                    || c.equals("android.view.LayoutInflater") || c.startsWith("org.lsposed")) {
                continue;
            }
            sb.append(c).append('.').append(e.getMethodName()).append(" <- ");
            if (++added >= 8) {
                break;
            }
        }
        return sb.toString();
    }

    private static void log(String msg) {
        if (LINES.incrementAndGet() > MAX_LINES) {
            return;
        }
        Log.i(TAG, msg);
        try {
            XposedBridge.log(TAG + ": " + msg);
        } catch (Throwable ignored) {
        }
        appendToFile(msg);
    }

    private static void appendToFile(String msg) {
        synchronized (FILE_LOCK) {
            try {
                if (!fileTried) {
                    fileTried = true;
                    Object app = Class.forName("android.app.ActivityThread")
                            .getMethod("currentApplication").invoke(null);
                    if (app instanceof Context) {
                        logFile = new File(((Context) app).getFilesDir(), "clockprobe.log");
                    }
                }
                if (logFile == null) {
                    return;
                }
                try (FileWriter w = new FileWriter(logFile, true)) {
                    w.write(msg + "\n");
                }
            } catch (Throwable ignored) {
            }
        }
    }
}
