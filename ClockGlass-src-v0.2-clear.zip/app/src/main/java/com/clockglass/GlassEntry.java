package com.clockglass;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * ClockGlass v0.2-clear
 *
 * Adds a small, clear LiquidGlassView behind OPPO's real ColorOS big clock digits.
 * The stock clock is not modified. Disable this LSPosed module to remove the effect.
 */
public class GlassEntry implements IXposedHookLoadPackage {

    private static final String TAG = "ClockGlass";
    private static final String GLASS_CLASS = "com.example.liquidglass.LiquidGlassView";
    private static final String GLASS_TAG = "clockglass_lens";
    private static final String CLOCK_CLASS_SUFFIX = ".ClockTimeView";
    private static final String CLOCK_ID_NAME = "clock_time";

    // Mild blur: blurAmount is a fraction of the glass view's size in this library.
    private static final float BLUR_AMOUNT = 0.02f;
    private static final float DISPERSION = 0.04f;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;

        log("v0.2-clear loaded in " + lpparam.processName);
        try {
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                final View v = (View) param.thisObject;
                                if (!v.getClass().getName().endsWith(CLOCK_CLASS_SUFFIX)) return;
                                if (!CLOCK_ID_NAME.equals(idName(v))) return;

                                v.post(new Runnable() {
                                    @Override public void run() {
                                        attachGlass(v);
                                    }
                                });
                            } catch (Throwable t) {
                                log("attach hook error: " + t);
                            }
                        }
                    });
            log("hook installed");
        } catch (Throwable t) {
            log("could not hook View.onAttachedToWindow: " + t);
        }
    }

    private static void attachGlass(View clock) {
        try {
            ViewParent pp = clock.getParent();
            if (!(pp instanceof FrameLayout)) {
                log("clock parent is not a FrameLayout: " +
                        (pp == null ? "null" : pp.getClass().getName()));
                return;
            }

            final FrameLayout parent = (FrameLayout) pp;
            if (parent.findViewWithTag(GLASS_TAG) != null) return;

            Rect lensBounds = findDigitBounds(clock, parent);
            if (lensBounds == null || lensBounds.width() <= 0 || lensBounds.height() <= 0) {
                log("digit containers not found/measured; refusing full-parent lens");
                return;
            }

            Object obj = createGlass(clock.getContext());
            if (!(obj instanceof View)) {
                log("glass object is not a View: " + obj);
                return;
            }

            final View glass = (View) obj;
            glass.setTag(GLASS_TAG);
            configure(glass, clock);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    lensBounds.width(), lensBounds.height(), Gravity.TOP | Gravity.LEFT);
            lp.leftMargin = lensBounds.left;
            lp.topMargin = lensBounds.top;

            int index = Math.max(parent.indexOfChild(clock), 0);
            parent.addView(glass, index, lp);

            log("digit lens bounds=" + lensBounds.toShortString()
                    + " parent=" + parent.getClass().getName()
                    + " index=" + index);

            glass.postDelayed(new Runnable() {
                @Override public void run() {
                    log("lens size " + glass.getWidth() + "x" + glass.getHeight()
                            + " vis=" + glass.getVisibility()
                            + " attached=" + glass.isAttachedToWindow());
                }
            }, 1200);

        } catch (Throwable t) {
            log("attach failed: " + t + " | " + shortStack(t));
        }
    }

    /**
     * The verified OPPO tree has separate hour/minute digit containers.
     * Their screen-space union is converted to the sibling FrameLayout's coordinates.
     */
    private static Rect findDigitBounds(View clock, ViewGroup parent) {
        String[] names = {
                "clock_time_hour_container",
                "clock_time_minutes_container"
        };

        int[] parentLoc = new int[2];
        parent.getLocationOnScreen(parentLoc);
        Rect union = null;

        for (String name : names) {
            int id = clock.getResources().getIdentifier(
                    name, "id", clock.getContext().getPackageName());
            if (id == 0) {
                log("digit id not found: " + name
                        + " package=" + clock.getContext().getPackageName());
                continue;
            }

            View target = clock.findViewById(id);
            if (target == null || target.getVisibility() != View.VISIBLE
                    || target.getWidth() <= 0 || target.getHeight() <= 0) {
                log("digit container unavailable: " + name);
                continue;
            }

            int[] loc = new int[2];
            target.getLocationOnScreen(loc);
            Rect r = new Rect(
                    loc[0] - parentLoc[0] - parent.getPaddingLeft(),
                    loc[1] - parentLoc[1] - parent.getPaddingTop(),
                    loc[0] - parentLoc[0] - parent.getPaddingLeft() + target.getWidth(),
                    loc[1] - parentLoc[1] - parent.getPaddingTop() + target.getHeight());

            if (union == null) union = new Rect(r);
            else union.union(r);

            log(name + " bounds=" + r.toShortString()
                    + " class=" + target.getClass().getName());
        }
        return union;
    }

    private static Object createGlass(Context ctx) throws Exception {
        Class<?> c = Class.forName(GLASS_CLASS, true, GlassEntry.class.getClassLoader());
        try {
            return c.getConstructor(Context.class).newInstance(ctx);
        } catch (NoSuchMethodException e) {
            return c.getConstructor(Context.class, AttributeSet.class).newInstance(ctx, null);
        }
    }

    private static void configure(View glass, View clock) {
        float d = clock.getContext().getResources().getDisplayMetrics().density;

        // Keep the lens subtle: small refraction rim, restrained dispersion, almost no tint.
        call(glass, "setCornerRadius", 34f * d);
        call(glass, "setRefractionHeight", 10f * d);
        call(glass, "setBevelWidth", 14f * d);
        call(glass, "setRefractionFalloff", 2f);
        call(glass, "setDispersionStrength", DISPERSION);
        call(glass, "setBlurAmount", BLUR_AMOUNT);
        call(glass, "setEnableBackdropBlur", true);
        call(glass, "setGlassTint", 0xFFFFFFFF, 0.0f);

        // CLEAR is the library's documented high-transparency material.
        try {
            Class<?> materialClass = Class.forName(
                    "com.example.liquidglass.GlassMaterial",
                    true, glass.getClass().getClassLoader());
            Object clear = Enum.valueOf((Class) materialClass, "CLEAR");
            call(glass, "setMaterial", clear);
            log("material requested = CLEAR");
        } catch (Throwable t) {
            log("could not select CLEAR material: " + t);
        }

        call(glass, "setEnableDynamicBackground", true);
        call(glass, "setEnablePressEffect", false);
        call(glass, "setEnableSensorHighlight", false);

        // Keep the verified window-root source for now; log the wallpaper candidate
        // separately so it can be evaluated without blindly switching to a preload view.
        View root = clock;
        while (root.getParent() instanceof View) root = (View) root.getParent();

        int wallpaperId = root.getResources().getIdentifier(
                "kgd_pictoral_preload_view_layout", "id",
                root.getContext().getPackageName());
        if (wallpaperId != 0) {
            View wallpaperCandidate = root.findViewById(wallpaperId);
            if (wallpaperCandidate != null) {
                log("wallpaper candidate=" + wallpaperCandidate.getClass().getName()
                        + " size=" + wallpaperCandidate.getWidth() + "x"
                        + wallpaperCandidate.getHeight()
                        + " visibility=" + wallpaperCandidate.getVisibility());
            } else {
                log("wallpaper candidate id exists but view is absent");
            }
        } else {
            log("wallpaper candidate id not found in " + root.getContext().getPackageName());
        }

        call(glass, "setBackdropSource", root);
        log("backdrop source = " + root.getClass().getName() + "#" + idName(root));

        glass.setClickable(false);
        glass.setFocusable(false);
        glass.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    /** Calls a public setter by name and argument count; logs missing/incompatible APIs. */
    private static boolean call(Object target, String name, Object... args) {
        Method[] methods = target.getClass().getMethods();
        for (Method m : methods) {
            if (!m.getName().equals(name) || m.getParameterTypes().length != args.length) continue;
            try {
                m.invoke(target, args);
                return true;
            } catch (IllegalArgumentException e) {
                // Try another overload.
            } catch (Throwable t) {
                log(name + " failed: " + t);
                return false;
            }
        }
        log("no usable method: " + name + "/" + args.length);
        return false;
    }

    private static String idName(View v) {
        int id = v.getId();
        if (id == View.NO_ID) return "-";
        try {
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "0x" + Integer.toHexString(id);
        }
    }

    private static String shortStack(Throwable t) {
        Throwable root = t;
        while (root.getCause() != null && root.getCause() != root) root = root.getCause();
        StringBuilder sb = new StringBuilder(root.toString());
        StackTraceElement[] st = root.getStackTrace();
        for (int i = 0; i < st.length && i < 6; i++) {
            sb.append(" <- ").append(st[i].getClassName()).append('.').append(st[i].getMethodName());
        }
        return sb.toString();
    }

    private static void log(String msg) {
        Log.i(TAG, msg);
        try {
            XposedBridge.log(TAG + ": " + msg);
        } catch (Throwable ignored) { }
    }
}
