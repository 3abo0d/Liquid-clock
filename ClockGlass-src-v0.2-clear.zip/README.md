ClockGlass v0.2-clear

This build targets a small clear lens behind OPPO's verified big-clock digit containers.
It requests the library's documented CLEAR material, removes glass tint, and uses a mild
initial blur setting. The backdrop remains the SystemUI window root pending confirmation
that the wallpaper view is actually captured.

Build: use the existing ClockGlass GitHub Actions workflow.
Install: update/install the APK, enable Clock Glass in LSPosed with System UI in scope,
then restart SystemUI.
Logs:
grep -h "ClockGlass:" /data/adb/lspd/log/verbose_*.log | tail -n 120
Remove:
pm uninstall com.clockglass
then restart SystemUI.
